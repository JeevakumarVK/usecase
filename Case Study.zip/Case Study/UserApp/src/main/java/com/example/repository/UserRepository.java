package com.example.repository;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.example.model.UserDao;
public interface UserRepository extends CrudRepository<UserDao, Integer> {
    UserDao findByUsername(String username);
    List<UserDao> findByRole(String role);
}