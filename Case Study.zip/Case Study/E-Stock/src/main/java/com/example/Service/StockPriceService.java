package com.example.Service;

import com.example.Models.StockPrice;

public interface StockPriceService {
    void UpdateStockPrice(long companyCode, StockPrice newPrice);
}
