package com.example.Models;

public enum StockExchange {
    NSE,
    BSE
}
