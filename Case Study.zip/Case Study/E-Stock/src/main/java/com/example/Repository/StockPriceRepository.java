package com.example.Repository;

import com.example.Models.StockPrice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.lang.Long;

@Repository
public interface StockPriceRepository extends JpaRepository<StockPrice,Long> {

}

