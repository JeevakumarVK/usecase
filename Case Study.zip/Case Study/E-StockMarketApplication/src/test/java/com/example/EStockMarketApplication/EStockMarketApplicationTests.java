package com.example.EStockMarketApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EStockMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
