package com.example.dto;

public class JwtResponse {
}
