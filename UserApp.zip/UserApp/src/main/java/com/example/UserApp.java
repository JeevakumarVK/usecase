package com.example;

import com.example.entity.UserInfo;
import com.example.repository.UserInfoRepository;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class UserApp {
	@Autowired
	private UserInfoRepository userRepo;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@PostConstruct
	public void initRoleAndUser() {


		UserInfo adminUser = new UserInfo();
		adminUser.setName("Jeevakumar");
		adminUser.setEmail("jeevakumar@gmail.com");;
		adminUser.setPassword(getEncodedPassword("admin@pass"));
		adminUser.setRoles("ADMIN");
		userRepo.save(adminUser);

	}
	public String getEncodedPassword(String password) {
		return passwordEncoder.encode(password);
	}

	public static void main(String[] args) {
		SpringApplication.run(UserApp.class, args);
	}

}
