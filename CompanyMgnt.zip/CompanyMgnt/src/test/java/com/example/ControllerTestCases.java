package com.example;

import java.util.ArrayList;
import java.util.List;

import com.example.Entity.Company;
import com.example.Service.CompanyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.when;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.example.Controller.CompanyController;
import com.example.Repository.CompanyRepository;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ControllerTestCases {
	
	@Mock
	private CompanyService cs;
	
	@Mock
	private CompanyRepository cr;
	
	@InjectMocks
	private CompanyController cc;
	
	@Autowired
	private MockMvc mockmvc;
	
	@BeforeEach
	public void init()
	{
		MockitoAnnotations.openMocks(this);
		mockmvc = MockMvcBuilders.standaloneSetup(cc).build();
	}
	
	private List<Company> userlist = new ArrayList<>();
	
	
	@Test
	public void testRegister() throws Exception {
 Company obj = new Company();
		
		obj.setCompanyCEO("hi");
		obj.setCompanyCode(45256L);
		obj.setCompanyName("microsoft");
		obj.setCompanyTurnover(3253478L);
		obj.setCompanyWebsite("afegygc.com");
		obj.setStockExchange("nse");
		

		userlist.add(obj);
		when(cs.saveCompany(any())).thenReturn(obj);
		
		
		Company u1 = cs.saveCompany(obj);
		
		
		assertEquals(1, userlist.size());
		
	mockmvc.perform(MockMvcRequestBuilders.post("/api/v1.0/market/company/register").contentType(MediaType.APPLICATION_JSON)
			.content(new ObjectMapper().writeValueAsString(obj)))
						.andExpect(MockMvcResultMatchers.status().isCreated());
		
	}

}
