package com.example;

import com.example.Entity.Stock;
import com.example.Service.CompanyService;
import com.example.Exception.CompanyNotFoundException;
import com.example.Entity.Company;
import com.example.Repository.StockRepository;
import com.example.Model.StockInputModel;
import com.example.Service.StockServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class StockServiceImplTest {

    @Mock
    private StockRepository stockRepo;

    @Mock
    private CompanyService companyService;

    @InjectMocks
    private StockServiceImpl stockService;

    private StockInputModel sampleInput;

    @BeforeEach
    public void setUp() {
        sampleInput = new StockInputModel();
        sampleInput.setStockPrice(100.0);
        sampleInput.setCompanyCode(1L);
    }

    @Test
    public void testAddStock() throws CompanyNotFoundException {
        Company sampleCompany = new Company();
        sampleCompany.setCompanyCode(1L);
        when(companyService.getByID(1L)).thenReturn(Optional.of(sampleCompany));
       when(stockRepo.save(any(Stock.class))).thenReturn(new Stock());
        stockService.addStock(sampleInput);
        verify(companyService, atLeastOnce()).getByID((1L));
        verify(stockRepo, atLeastOnce()).save(any(Stock.class));
    }


    @Test
    public void testAddStockCompanyIdNotFound() throws CompanyNotFoundException{
        when(companyService.getByID(anyLong())).thenReturn(null);
        assertThrows(CompanyNotFoundException.class, () -> {
            stockService.addStock(sampleInput);
        });
        verify(companyService, times(1)).getByID(anyLong());
        verify(stockRepo, never()).save(any());

    }}

