package com.example;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.example.Entity.Company;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.example.Controller.CompanyController;
import com.example.Repository.CompanyRepository;
import com.example.Service.CompanyImpl;

//@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest
class ServiceTestCases {
    
    @Autowired
    private CompanyImpl cs;
    
    @MockBean
    private CompanyRepository cr;
    
    @Mock
    private CompanyController cc;
    
    
    
  
    @Test
    public void addUserSuccess() throws Exception {
        // Create a new company object
        Company userobj = new Company();
        userobj.setCompanyCEO("hi");
        userobj.setCompanyCode(45256L);
        userobj.setCompanyName("microsoft");
        userobj.setCompanyTurnover(3253478L);
        userobj.setCompanyWebsite("afegygc.com");
        userobj.setStockExchange("nse");
        
        // Save the company object using the CompanyService
        Company savedCompany = cr.save(userobj);
        System.out.println(savedCompany);
        assertNotNull(savedCompany);
        
        // Assert that the saved company object is equal to the original company object
       // assertEquals(userobj, savedCompany);
    }
    
    
}