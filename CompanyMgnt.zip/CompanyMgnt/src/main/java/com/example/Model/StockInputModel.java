package com.example.Model;

import lombok.Data;

@Data
public class StockInputModel {
	private double stockPrice;
	private Long companyCode;

}
