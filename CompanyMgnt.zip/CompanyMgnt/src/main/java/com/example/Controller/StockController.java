package com.example.Controller;

import com.example.Entity.Stock;
import com.example.Exception.CompanyNotFoundException;
import com.example.Exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Exception.IncorrectPasswordException;
import com.example.FeignClient.UserAuthenticationClient;
import com.example.Model.StockInputModel;
import com.example.Model.ValidateResponse;
import com.example.Service.StockServiceImpl;

@RestController
@RequestMapping("/api/v1.0/market/stock")
public class StockController {

	@Autowired
	private StockServiceImpl stockService;
	
	@Autowired
	private UserAuthenticationClient client;
	
	@PostMapping("/add/{companycode}")
	public ResponseEntity<Stock> addStock(@RequestHeader("Authorization") String token, @RequestBody StockInputModel input) throws CompanyNotFoundException, UserNotFoundException, IncorrectPasswordException{
		ValidateResponse response=client.validateUser(token);
		if(response.getValid()&& response.getRoleName().contains("ADMIN")) {
		Stock s = stockService.addStock(input);
		return new ResponseEntity<>(s,HttpStatus.OK);
	}
		throw new IncorrectPasswordException("Invalid User");
	}
}
