package com.example.FeignClient;

import com.example.Exception.IncorrectPasswordException;
import com.example.Exception.UserNotFoundException;
import com.example.Model.ValidateResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;

@FeignClient(url="localhost:8085/api/v1.0/user", name="LoginApplication")
public interface UserAuthenticationClient {
	
	@PostMapping("/validate")
    public ValidateResponse validateUser(@RequestHeader("Authorization") String token) throws UserNotFoundException, IncorrectPasswordException;

}
