package com.example.Service;

import com.example.Entity.Stock;
import com.example.Exception.CompanyNotFoundException;
import com.example.Model.StockInputModel;
import com.example.Repository.StockRepository;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;


public interface StockService {
	
	public Stock addStock(StockInputModel input) throws CompanyNotFoundException;


}
