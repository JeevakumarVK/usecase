package com.example.Service;

import java.util.List;
import java.util.Optional;

import com.example.Entity.Company;
import com.example.Exception.CompanyNotFoundException;

public interface CompanyService {

	abstract Company saveCompany(Company company);

	abstract Optional<Company> getByID(long companyCode);

	abstract List<Company> getAllCompanies();

	abstract  void deleteCompany(long companyCode) throws CompanyNotFoundException;
	
	public Company updateCompany(Long companyCode, Company company) throws CompanyNotFoundException;


}
